#ifndef degree_h
#define degree_h

/* define an enumerated data type DegreeProgram */

enum class DegreeProgram {SECURITY, NETWORK, SOFTWARE};

#endif /* degree_h */
